

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="nk-wrap">
        <?php echo $__env->make('admin.top_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="nk-content ">
            <div class="container-fluid">
                <div class="nk-content-inner">
                    <div class="nk-content-body">
                        <div class="components-preview wide-md mx-auto">
                            <div class="nk-block-head">
                                <div class="nk-block-head-content">
                                    <div class="nk-block-head-sub"><a class="back-to" onclick="window.history.back()" href="javascript:void(0)"><em class="icon ni ni-arrow-left"></em><span>Back</span></a></div>
                                    <div class="toggle-wrap nk-block-tools-toggle" style="display: inline-flex; width: 100% !important">
                                        <h2 class="nk-block-title fw-normal col-lg-10">Post List</h2>
                                    </div>
                                </div>
                            </div>
                            <div class="nk-block nk-block-lg">
                                <div class="card card-preview">
                                    <div class="card-inner">
                                        <div class="preview-block">
                                            <?php if($errors->any()): ?>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <script>
                                                        window.EliteCodec.Toast(`<h5>Error!</h5><p><?php echo e($error); ?></p>`, "error", { position: "top-right" })
                                                    </script>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <?php if(session()->has('success')): ?>
                                                <script>
                                                    window.EliteCodec.Toast(`<h5>Success</h5><p><?php echo e(session()->get('success')); ?></p>`, "success", { position: "top-right" })
                                                </script>
                                            <?php endif; ?>
                                            <table class="datatable-init nowrap table">
                                                <thead>
                                                    <tr>
                                                        <th>S/N</th>
                                                        <th>Post Title</th>
                                                        <th>Post Category</th>
                                                        <th>Post Sub-Category</th>
                                                        <th>Post Tags</th>
                                                        <th>Publish Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($post->id); ?></td>
                                                            <td><?php echo e(ucwords($post->post_title)); ?></td>
                                                            <td><?php echo e(fetch_category($post->post_category)->category_name); ?></td>
                                                            <td></td>
                                                            <td>
                                                                <?php
                                                                    $tags = explode(',', $post->post_tags);
                                                                ?>
                                                                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php echo e('#'.$tag); ?>

                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </td>
                                                            <td>
                                                                <?php switch($post->post_status):
                                                                    case (1): ?>
                                                                        <span class="badge badge-success">Published</span>
                                                                        <?php break; ?>
                                                                
                                                                    <?php default: ?>
                                                                    <span class="badge badge-info">Unpublished</span>
                                                                <?php endswitch; ?>
                                                            </td>
                                                            <td>
                                                                <button type="button" class="btn btn-sm btn-danger" id="delete_post" data-id="<?php echo e($post->id); ?>"><em class="icon ni ni-trash"></em> Delete</button>
                                                                <a href="/store/drug/restock/<?php echo e($post->id); ?>" class="btn btn-sm btn-primary" id="edit"><em class="icon ni ni-edit-alt"></em> Edit</a>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Engr. Daniel Michael\Desktop\softdelta\resources\views/admin/post_list.blade.php ENDPATH**/ ?>