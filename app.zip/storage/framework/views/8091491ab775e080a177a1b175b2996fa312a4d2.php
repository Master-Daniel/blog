

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layout.guest_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="single-post spad">
        <div class="single-post__hero set-bg" data-setbg="<?php echo e(url('storage/images/img1.jpg')); ?>"></div>
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-8">
                    <div class="single-post__title">
                        <div class="single-post__title__meta">
                            <h2>10</h2>
                            <span>Sep</span>
                        </div>
                        <div class="single-post__title__text">
                            
                            <h4>David Edevbie Completely Failed To Prove Allegations Of Forgery Against Rt. Hon.  Sheriff Francis Orohwedor Oborevwori</h4>
                            
                        </div>
                    </div>
                    <div class="single-post__social__item">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fa fa-youtube-play"></i></a></li>
                        </ul>
                    </div>
                    <div class="single-post__top__text">
                        <p>A critical look at the judgement of the Court of Appeal, Abuja, involving Rt. Hon. Sheriff Francis Orohwedor Oborevwori and Chief David Edevbie and others will leave no one in doubt that the judgement was/is rooted in law and impeccable reasoning. The media trial, twisting of facts and rabble rousing should therefore stop, as it clearly does not augur well for the image of our dear state. </p>
                    </div>
                    <div class="single-post__middle__text">
                        <p>Honourable Justice P.O. Ige JCA, one of the Honourable Justices of the Court of Appeal who determined the appeal stated thus:</p>
                    </div>
                    <div class="single-post__quote">
                        <p>The 1st Respondent did not call any lucid or credible evidence to support the serious and grave criminal allegations made against the Appellant to justify the invocation of the consequences of Section 29(5) & (6) of the Electoral Act 2022. There was/is no evidence from any of the institutions that issued the said educational certificates and results disclaiming any of the certificates relied upon by the Appellant to seek election to the Office of the Governor of Delta State.</p>
                    </div>
                    <div class="single-post__desc">
                        <p>A situation where the 1st Respondent as Plaintiff did not find it necessary or bothered to inquire from all the institutions and Registry of Courts as to whether or not they issued those certificates or documents and to who were they validly issued, whether to the Appellant or other persons is a complete failure to discharge the onus on the 1st Respondent to prove beyond reasonable doubt the allegations of forgery and faking of documents against the Appellant.</p>
                        <p>The Forged documents and their originals must be produced by the 1st Respondent in order to discern which are the originals or authentic certificates and how they were forged. It must be established that the Appellant indeed forged those documents and certificates listed by the 1st Respondent is his Affidavit in Support of the Originating Summons. Failure to call evidence from the institutions that issued the certificates and other impugned documents and the prove of particulars of forgery and fake documents alleged on those certificates and false information in the Affidavits of the 1st Respondent knocked the bottom out of the 1st Respondent’s case as Plaintiff at the lower Court…</p>
                    </div>
                    <div class="single-post__more__details">
                        <div class="row">
                            <div class="col-lg-6 col-md-6">
                                <img src="<?php echo e(url('storage/images/img8.jpg')); ?>" alt="">
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <p>On the variation or what the 1st Respondent referred to as inconsistency in the names of the Appellant, the 1st Respondent made emphatic deposition in his Affidavit that because of those variation or inconsistencies in the name of the Appellant, the Appellant is not the owner of the certificates or documents that he presented to the 2nd and 3rd Respondents</p>
                                <p>The 1st Respondent failed to prove or establish by the Affidavits evidence before the lower Court the owner of those educational certificates and other documents aside the Appellant who claims the ownership of the documents. The 1st Respondent also failed to proffer any cogent or credible evidence before the lower Court to entitle him to the reliefs sought on the Originating Summons. The heinous allegations of swearing to false Affidavit, forging and faking of educational credentials made by the 1st Respondent against the Appellant cannot be established or proved by mere assertions and comparison carried out by the 1st Respondent in the Supporting  Affidavit to his Originating Summons.</p>
                            </div>
                            <div class="single-post__last__text">
                                <p> The 1st Respondent is under a duty to produce the originals of the credentials or certificates claimed by the Appellant as belonging to him and the forged documents and certificates before the lower Court. That is not all he failed to prove that the Appellant actually forged or faked any of the documents or certificates attached to the alleged false Affidavits. Further on the allegations of the 1st Respondent that the Appellant laid claims to various certificates that do not belong to him and contained different and varied names all of which the 1st Defendant now Appellant now fraudulently seeks to ascribe to himself in a chameleonic manner, the 1st Respondents failed to prove any of the allegations that those names do not belong to the Appellant.It is of paramount importance to note that the 1st Respondent sued the Appellant as “OBOREVWORI SHERIFF FRANCIS OROHWEDOR” and by the Supporting Affidavit sworn to by documents. The 1st Respondent, the names of the Appellant are contained in all the documents.  The 1st Respondent failed to prove that those names do not belong to the Appellant merely by the arrangement of the names or the person bearing the names apart from the Appellant. The 1st Respondent did not prove or establish to which advantage the names have been used over the 1st Respondents right to contest and other Aspirants who participated in the PDP’S Primaries to elect its candidate for Delta State Governorship Election of 2023 which the Appellant won. The lower Court decision in favor of the 1st Respondent is perverse...</p>
                                <p>The above succinct position of the Noble Lords of the Court of Appeal is completely in line with recently decided cases of the Supreme Court. It is preposterous and an anathema for anyone or group of people who are less seised of the facts and  the erudite judgement of the Court to at this stage continue to dabble into an area they know nothing about! At this juncture, it will be of greater interest to PDP Family in particular and Deltans in general to give peace a chance.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="single-post__last__text">
                        <p>I have no doubt in my mind that despite the legal tussle which was uncalled for, there is room for accommodation of those on the other side of the political divide by the winner of the Court of Appeal judgement. Rt. Hon. Sheriff Francis Orohwedor Oborevwori deserves the support of all Deltans.</p>
                    </div>
                    <div class="single-post__next__previous">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <a href="#" class="single-post__previous">
                                    <h6><span class="arrow_carrot-left"></span> Previous posts</h6>
                                    
                                </a>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <a href="#" class="single-post__next">
                                    <h6>Next posts <span class="arrow_carrot-right"></span> </h6>
                                    
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="single-post__leave__comment">
                        <div class="widget__title">
                            <h4>Leave a comment</h4>
                        </div>
                        <form action="#">
                            <div class="input-list">
                                <input type="text" placeholder="Name">
                                <input type="text" placeholder="Email">
                                <input type="text" placeholder="Website">
                            </div>
                            <textarea placeholder="Message"></textarea>
                            <button type="submit" class="site-btn">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Engr. Daniel Michael\Desktop\softdelta\resources\views/let-there-be-peace.blade.php ENDPATH**/ ?>