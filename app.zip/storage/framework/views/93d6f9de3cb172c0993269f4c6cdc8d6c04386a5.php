

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="nk-wrap">
        <?php echo $__env->make('admin.top_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="nk-content ">
            <div class="container-fluid">
                <div class="nk-content-inner">
                    <div class="nk-content-body">
                        <div class="components-preview wide-md mx-auto">
                            <div class="nk-block-head">
                                <div class="nk-block-head-content">
                                    <div class="nk-block-head-sub"><a class="back-to" onclick="window.history.back()" href="javascript:void(0)"><em class="icon ni ni-arrow-left"></em><span>Back</span></a></div>
                                    <div class="toggle-wrap nk-block-tools-toggle" style="display: inline-flex; width: 100% !important">
                                        <h2 class="nk-block-title fw-normal col-lg-10">Add New Post</h2>
                                    </div>
                                </div>
                            </div>
                            <div class="nk-block nk-block-lg">
                                <div class="card card-preview">
                                    <div class="card-inner">
                                        <div class="preview-block">
                                            <?php if($errors->any()): ?>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <script>
                                                        window.EliteCodec.Toast(`<h5>Error!</h5><p><?php echo e($error); ?></p>`, "error", { position: "top-right" })
                                                    </script>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <?php if(session()->has('success')): ?>
                                                <script>
                                                    window.EliteCodec.Toast(`<h5>Success</h5><p><?php echo e(session()->get('success')); ?></p>`, "success", { position: "top-right" })
                                                </script>
                                            <?php endif; ?>
                                            <div class="nk-block nk-block-lg">
                                                <form action="<?php echo e(route('create.post')); ?>" id="post_form" method="post" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="nk-block-head">
                                                        <div class="nk-block-head-content">
                                                            <h4 class="title nk-block-title">Enter Post Details</h4>
                                                        </div>
                                                    </div>
                                                    <div class="card">
                                                        <div class="form-group">
                                                            <label for="post_title">Post Title</label>
                                                            <input type="text" class="form-control" id="post_title" value="<?php echo e(old('post_title')); ?>" name="post_title" placeholder="Enter Post Title" />
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="post_summary">Post Summary</label>
                                                            <textarea id="post_summary" name="post_summary" cols="30" rows="5" class="form-control"><?php echo e(old('post_summary')); ?></textarea>
                                                            <div id="count">Characters: 255</div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="post_body">Enter Post</label>
                                                            <textarea rows="20" name="post_body" class="form-control tinymce-basic"><?php echo e(old('post_body')); ?></textarea>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-6 form-group">
                                                                <label for="post_category">Post Category</label>
                                                                <select name="post_category" data-search="on" id="post_category" class="form-control form-select">
                                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                            <div class="col-6 form-group">
                                                                <label for="post_sub_category">Post Sub-Category</label>
                                                                <select name="post_sub_category" data-search="on" id="post_sub_category" class="form-control form-select">
                                                                    
                                                                </select>
                                                            </div>
                                                            <div class="col-6 form-group">
                                                                <label for="post_date">Post Date</label>
                                                                <input type="text" name="post_date" value="<?php echo e(old('post_date')); ?>" id="date" class="form-control date-picker">
                                                            </div>
                                                            <div class="col-6 form-group">
                                                                <label for="post_tags">Post Tags</label>
                                                                <input type="text" name="post_tags" value="<?php echo e(old('post_tags')); ?>" data-role="tagsinput" id="post_tags" class="form-control" placeholder="Enter tags seperated by comma (,)">
                                                            </div>
                                                            <div class="col-6 form-group">
                                                                <select name="post_section" id="section" class="form-select form-control">
                                                                    <option selected disabled>Select Section</option>
                                                                    <option value="top">Top</option>
                                                                    <option value="hero">Hero</option>
                                                                    <option value="recent">Recent Post</option>
                                                                    <option value="featured">Featured Post</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-6">
                                                                <label for="file" class="custom-file-label">Upload Post Image</label>
                                                                <input type="file" id="file" name="file">
                                                            </div>
                                                        </div>
                                                        <button type="submit" id="" class="btn btn-primary btn-block mt-5">Add Post</button>
                                                    </div>    
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\engrd\OneDrive\Desktop\softdelta\resources\views/admin/create_post.blade.php ENDPATH**/ ?>