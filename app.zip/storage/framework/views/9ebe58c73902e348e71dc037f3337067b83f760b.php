

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layout.guest_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="single-post spad">
        <div class="single-post__hero set-bg" data-setbg="<?php echo e(url('storage/images/img18.jpg')); ?>"></div>
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-8">
                    <div class="single-post__title">
                        <div class="single-post__title__meta">
                            <h2>10</h2>
                            <span>Sep</span>
                        </div>
                        <div class="single-post__title__text">
                            
                            <h4>OMO-AGEGE'S NIGHTMARE HAS JUST BEGUN</h4>
                            
                        </div>
                    </div>
                    <div class="single-post__social__item">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fa fa-youtube-play"></i></a></li>
                        </ul>
                    </div>
                    <div class="single-post__top__text">
                        <p>Senator Ovie Omo-Agege's latest rant is a clear indication that he is not only suffering from delusions of grandeur, but also a confirmation that his worst fear is coming to pass.</p>
                    </div>
                    <div class="single-post__quote">
                        <p>It goes without saying that the restoration of Rt. Hon. Sheriff Oborevwori's mandate by the Court of Appeal has sent shivers down the spine of the Orogun Senator. But to put up a front, failed former presidential spokesman, Ima Niboro, who now parades himself as Omo-Agege's Director of Communication, issued a meaningless press statement in a futile taunt of the PDP candidate</p>
                    </div>
                    <div class="single-post__desc">
                        <p>The truth is that with Oborevwori's emergence, the APC is already staring at defeat in the 2023 Delta governorship election. Speaker Oborevwori's grassroots appeal, pan-Delta disposition  democratic credentials, leadership acumen, and generosity of spirit are qualities Deltans want to see in their next governor. These qualities are in sharp contrast to Omo-Agege's selfish, self-serving, self-centred, bigoted, and anti-democratic stance (he voted against electronic voting and defended it). He is such a man of tunnel vision, who has justifiably, earned the sobriquet of Orogun Senator because virtually all his constituency projects are concentrated in his native Orogun village even though he is supposed to be representing the entire Delta Central in the Senate. Deltans certainly do not need and cannot vote for such a parochial person.</p>
                    </div>
                    <div class="single-post__more__details">
                        <div class="row">
                            <div class="single-post__last__text">
                                <p>The truth is that with Oborevwori's emergence, the APC is already staring at defeat in the 2023 Delta governorship election. Speaker Oborevwori's grassroots appeal, pan-Delta disposition  democratic credentials, leadership acumen, and generosity of spirit are qualities Deltans want to see in their next governor. These qualities are in sharp contrast to Omo-Agege's selfish, self-serving, self-centred, bigoted, and anti-democratic stance (he voted against electronic voting and defended it). He is such a man of tunnel vision, who has justifiably, earned the sobriquet of Orogun Senator because virtually all his constituency projects are concentrated in his native Orogun village even though he is supposed to be representing the entire Delta Central in the Senate. Deltans certainly do not need and cannot vote for such a parochial person.
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="single-post__next__previous">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <a href="#" class="single-post__previous">
                                    <h6><span class="arrow_carrot-left"></span> Previous posts</h6>
                                    
                                </a>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <a href="#" class="single-post__next">
                                    <h6>Next posts <span class="arrow_carrot-right"></span> </h6>
                                    
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="single-post__leave__comment">
                        <div class="widget__title">
                            <h4>Leave a comment</h4>
                        </div>
                        <form action="#">
                            <div class="input-list">
                                <input type="text" placeholder="Name">
                                <input type="text" placeholder="Email">
                                <input type="text" placeholder="Website">
                            </div>
                            <textarea placeholder="Message"></textarea>
                            <button type="submit" class="site-btn">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Engr. Daniel Michael\Desktop\softdelta\resources\views/nightmare.blade.php ENDPATH**/ ?>