

<?php $__env->startSection('content'); ?>
    <header id="header">
        <?php echo $__env->make('layout.guest_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
        <div id="post-header" class="page-header">
			<div class="background-img" style="background-image: url(<?php echo e(asset('public/uploads/'.$post_details->post_image)); ?>);"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-10">
						<div class="post-meta">
							<a class="post-category cat-2" href="javascript:void(0)"><?php echo e(__('Category')); ?></a>
							<span class="post-date"><?php echo e(date('F d, Y', strtotime($post_details->created_at))); ?></span>
						</div>
						<h1><?php echo e(ucwords($post_details->title)); ?></h1>
					</div>
				</div>
			</div>
		</div>
    </header>

    <div class="section">
		<div class="container">
			<div class="row">
				<div class="col-md-8">
					<div class="section-row sticky-container">
						<div class="main-post">
							<h3><?php echo e(ucwords($post_details->post_title)); ?></h3>
							<?php echo html_entity_decode($post_details->post_body); ?>

						</div>
						<div class="post-shares sticky-shares">
							<a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url('/posts/details')); ?>/<?php echo e($post_details->post_slug); ?>" target="_blank" class="share-facebook"><i class="fa fa-facebook"></i></a>
							<a href="http://twitter.com/share?text=<?php echo e($post_details->post_title); ?>&url=<?php echo e(url('/posts/details')); ?>/<?php echo e($post_details->post_slug); ?>&hashtags=<?php echo e($post_details->post_tags); ?>" target="_blank" class="share-twitter"><i class="fa fa-twitter"></i></a>
							<a href="javascript:void(0)"><i class="fa fa-envelope"></i></a>
						</div>
					</div>

					<div class="section-row text-center">
						<a href="#" style="display: inline-block;margin: auto;">
							<img class="img-responsive" src="img/xad-2.jpg.pagespeed.ic.bUoDgOb5IT.jpg" alt="">
						</a>
					</div>

					


					


					<div class="section-row">
						<div class="section-title">
							<h2>Leave a reply</h2>
							<p>your email address will not be published. required fields are marked *</p>
						</div>
						<form class="post-reply">
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<span>Name *</span>
										<input class="input" type="text" name="name">
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<span>Email *</span>
										<input class="input" type="email" name="email">
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<textarea class="input" name="message" placeholder="Message"></textarea>
									</div>
									<button class="primary-button">Submit</button>
								</div>
							</div>
						</form>
					</div>

				</div>


				<div class="col-md-4">

					<div class="aside-widget text-center">
						<a href="#" style="display: inline-block;margin: auto;">
							<img class="img-responsive" src="img/xad-1.jpg.pagespeed.ic.C1dNWPxojd.jpg" alt="">
						</a>
					</div>

                    <?php if(empty($most_reads)): ?>
                        <div class="aside-widget">
                            <div class="section-title">
                                <h2>Most Read</h2>
                            </div>

                            <div class="post post-widget">
                                <a class="post-img" href="blog-post.html"><img
                                        src="img/xwidget-1.jpg.pagespeed.ic.nqEkEDP2_z.jpg" alt=""></a>
                                <div class="post-body">
                                    <h3 class="post-title"><a href="blog-post.html">Tell-A-Tool: Guide To Web Design And
                                            Development Tools</a></h3>
                                </div>
                            </div>
                            
                        </div>
                    <?php endif; ?>
					
					<?php if(empty($posts)): ?>
                        <div class="aside-widget">
                            <div class="section-title">
                                <h2>Featured Posts</h2>
                            </div>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="post post-thumb">
                                    <a class="post-img" href="<?php echo e('/posts/details/'.$post->post_slug); ?>">
                                        <img src="<?php echo e(asset('public/uploads/'.$post->post_image)); ?>" alt="">
                                    </a>
                                    <div class="post-body">
                                        <div class="post-meta">
                                            <a class="post-category cat-3" href="javascript:void(0)"><?php echo e(__('Category')); ?></a>
                                            <span class="post-date"><?php echo e(date('F d, Y', strtotime($post->created_at))); ?></span>
                                        </div>
                                        <h3 class="post-title"><a href="<?php echo e('/posts/details/'.$post->post_slug); ?>"><?php echo e(ucwords($post->post_title)); ?></a></h3>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

					<div class="aside-widget">
						<div class="section-title">
							<h2>Catagories</h2>
						</div>
						<div class="category-widget">
							<ul>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="javascript:void(0)" class="cat-1"><?php echo e($category->category_name); ?><span><?php echo e(get_number_of_category_posts($category->id)); ?></span></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
					</div>

					<div class="aside-widget">
						<div class="tags-widget">
							<ul>
								<li><a href="javascript:void(0)">Tags</a></li>
							</ul>
						</div>
					</div>
					<div class="aside-widget">
						<div class="section-title">
							<h2>Archive</h2>
						</div>
						<div class="archive-widget">
							<ul>
								<li><a href="javascript:void(0)">January 2022</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
    <script>
        const quote = document.querySelectorAll('blockquote')
        if (quote != null || quote != undefined) {
            quote.forEach(element => {
				element.classList.add('blockquote');
			});
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\engrd\OneDrive\Desktop\softdelta\resources\views/single-post.blade.php ENDPATH**/ ?>