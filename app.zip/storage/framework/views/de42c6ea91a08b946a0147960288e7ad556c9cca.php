<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="content-type" content="text/html;charset=utf-8" />
        <meta name="description" content="Foodeiblog Template">
        <meta name="keywords" content="s">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>RT HON Sherrif Oborevwori - Soft Delta</title>

        <!-- Google Font -->
        <link href="//fonts.googleapis.com/css73f1.css?family=Nunito+Sans:300,400,600,700,800,900&amp;display=swap"  rel="stylesheet">
        <link href="//fonts.googleapis.com/css1dbe.css?family=Unna:400,700&amp;display=swap" rel="stylesheet">
        <link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" />

    </head>
    <body class="">

        <?php echo $__env->yieldContent('content'); ?>

        <footer id="footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-5">
                        <div class="footer-widget">
                            <div class="footer-logo">
                                <a href="<?php echo e(route('home')); ?>" class="logo">
                                    <img src="<?php echo e(url('storage/images/site-logo.png')); ?>" alt="">
                                </a>
                            </div>
                            <ul class="footer-nav">
                                <li><a href="javascript:void(0)">Privacy Policy</a></li>
                                <li><a href="javascript:void(0)">Advertisement</a></li>
                            </ul>
                            <div class="footer-copyright">
                                <span>Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Developed by <a href="//elitecodec.com.ng" target="_blank">Elite Codec Inc.</a>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="footer-widget">
                                    <h3 class="footer-title">About Us</h3>
                                    <ul class="footer-links">
                                        <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
                                        <li><a href="<?php echo e(route('contact')); ?>">Contacts</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="footer-widget">
                                    <h3 class="footer-title">Catagories</h3>
                                    <ul class="footer-links">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="javascript:void(0)"><?php echo e($category['category_name']); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="footer-widget">
                            <h3 class="footer-title">Join our Newsletter</h3>
                            <div class="footer-newsletter">
                                <form>
                                    <input class="input" type="email" name="newsletter" placeholder="Enter your email">
                                    <button class="newsletter-btn"><i class="fa fa-paper-plane"></i></button>
                                </form>
                            </div>
                            <ul class="footer-social">
                                <li><a href="https://www.facebook.com/profile.php?id=100076807932501"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="https://twitter.com/softDelta2023/status/1570007990052306945?t=PaV8YodXIYOl7PScKtA9pQ&s=19"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="https://www.youtube.com/channel/UCjb02gX0VGb1zcb9OjC2Tvg"><i class="fa fa-youtube"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>

        

        <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/custom/notification.js')); ?>"></script>
        <script>eval(mod_pagespeed_15hy7ra_pu);</script>
	    <script>eval(mod_pagespeed_RDDE5qW6SI);</script>
    </body>
</html><?php /**PATH C:\Users\Engr. Daniel Michael\Desktop\softdelta\resources\views/layout/guest.blade.php ENDPATH**/ ?>