

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layout.guest_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="single-post spad">
        <div class="single-post__hero set-bg" data-setbg="<?php echo e(url('storage/images/img13.jpg')); ?>"></div>
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-8">
                    <div class="single-post__title">
                        <div class="single-post__title__meta">
                            <h2>10</h2>
                            <span>Sep</span>
                        </div>
                        <div class="single-post__title__text">
                            
                            <h4>Sheriff Oborevwori Political Career</h4>
                            
                        </div>
                    </div>
                    <div class="single-post__social__item">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fa fa-youtube-play"></i></a></li>
                        </ul>
                    </div>
                    <div class="single-post__top__text">
                        <p>As the Chairman of the Okpe Community, Oborevwori started his political career at the local level. But he first gained notoriety in 2015 when the Peoples Democracy Party chose him to represent Okpe State Constituency in the Delta State House of Assembly (PDP).</p>
                    </div>
                    <div class="single-post__quote">
                        <p>This comes after serving for 19 years in a number of important government posts, starting in 1996 as a councillor. Following the impeachment of the previous Speaker, Rt. Hon. Monday Igbuya, he was elected speaker of the Delta State House of Assembly on May 11, 2017.</p>
                    </div>
                    <div class="single-post__desc">
                        <p>Rt. Hon. Monday Igbuya, speaker. After winning the election to represent his electorate, the Okpe State Constituency, at the Delta State House of Assembly, he was re-elected as Speaker for a second term in 2019.
                            Oborevwori belongs to a number of professional organizations, such as the Nigerian Institute of Management (Chartered). He also holds fellowships from the Institute of Chartered Mediators and Conciliators and the Chartered Institute of Management Consultants, Canada (FICMC).
                            He received a Legislative Icon Award from the National Association of Nigerian Students (NANS) on May 14, 2018, in appreciation of the organization’s numerous educational initiatives and scholarship programs that benefit students all around Delta State.
                            A Chieftaincy Title, the Ukodo of Okpe, was conferred upon him by His Royal Majesty, the Orhorho 1, Orodje of Okpe, in honor of his contribution to the expansion and advancement of the Okpe Kingdom, as well as a tribute from his family.</p>
                    </div>
                    
                    <div class="single-post__next__previous">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <a href="#" class="single-post__previous">
                                    <h6><span class="arrow_carrot-left"></span> Previous posts</h6>
                                    
                                </a>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <a href="#" class="single-post__next">
                                    <h6>Next posts <span class="arrow_carrot-right"></span> </h6>
                                    
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="single-post__leave__comment">
                        <div class="widget__title">
                            <h4>Leave a comment</h4>
                        </div>
                        <form action="#">
                            <div class="input-list">
                                <input type="text" placeholder="Name">
                                <input type="text" placeholder="Email">
                                <input type="text" placeholder="Website">
                            </div>
                            <textarea placeholder="Message"></textarea>
                            <button type="submit" class="site-btn">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Engr. Daniel Michael\Desktop\softdelta\resources\views/political-career.blade.php ENDPATH**/ ?>