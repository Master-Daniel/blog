<?php $__env->startSection('content'); ?>

    <header id="header">
        <?php echo $__env->make('layout.guest_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>

    <div class="section">
        <div class="container">
            
            <?php if($posts): ?>
                <div class="row">
                    <?php ($array = []); ?>
                    <?php if($posts->count() > 0): ?>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($post->post_section == 'top' && !in_array($post->id, $array) && count($array) <= 2): ?>
                                <div class="col-md-6">
                                    <div class="post post-thumb">
                                        <a class="post-img" href="<?php echo e('/posts/details/'.$post->post_slug); ?>">
                                            <img src="<?php echo e(asset('public/uploads/'.$post->post_image)); ?>" alt="<?php echo e($post->post_title); ?>">
                                        </a>
                                        <div class="post-body">
                                            <div class="post-meta">
                                                <a class="post-category cat-2" href="javascript:void(0)"><?php echo e(__('Category')); ?></a>
                                                <span class="post-date"><?php echo e(date('F d, Y', strtotime($post->created_at))); ?></span>
                                            </div>
                                            <h3 class="post-title">
                                                <a href="<?php echo e('/posts/details/'.$post->post_slug); ?>"><?php echo e($post->post_title); ?></a>
                                            </h3>
                                        </div>
                                    </div>
                                </div>
                                <?php ($array[] = $post->id); ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="section-title">
                            <h2>Recent Posts</h2>
                        </div>
                    </div>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!in_array($post->id, $array) && count($array) <= 8): ?>
                            <div class="col-md-4">
                                <div class="post">
                                    <a class="post-img" href="<?php echo e('/posts/details/'.$post->post_slug); ?>">
                                        <img src="<?php echo e(asset('public/uploads/'.$post->post_image)); ?>" alt="">
                                    </a>
                                    <div class="post-body">
                                        <div class="post-meta">
                                            <a class="post-category cat-1" href="javascript:void(0)"><?php echo e(__('Category')); ?></a>
                                            <span class="post-date"><?php echo e(date('F d, Y', strtotime($post->created_at))); ?></span>
                                        </div>
                                        <h3 class="post-title"><a href="<?php echo e('/posts/details/'.$post->post_slug); ?>"><?php echo e($post->post_title); ?></a></h3>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php ($array[] = $post->id); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row">
                    <div class="col-md-8">
                        <div class="row">
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($post->post_section == 'hero'): ?>
                                    <div class="col-md-12">
                                        <div class="post post-thumb">
                                            <a class="post-img" href="<?php echo e('/posts/details/'.$post->post_slug); ?>">
                                                <img src="<?php echo e(asset('public/uploads/'.$post->post_image)); ?>" alt="">
                                            </a>
                                            <div class="post-body">
                                                <div class="post-meta">
                                                    <a class="post-category cat-3" href="javascript:void(0)"><?php echo e(__('Category')); ?></a>
                                                    <span class="post-date"><?php echo e(date('F d, Y', strtotime($post->created_at))); ?></span>
                                                </div>
                                                <h3 class="post-title"><a href="<?php echo e('/posts/details/'.$post->post_slug); ?>"><?php echo e($post->post_title); ?></a></h3>
                                            </div>
                                        </div>
                                    </div>
                                    <?php break; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!in_array($post->id, $array) && count($array) <= 14): ?>
                                    <div class="col-md-6">
                                        <div class="post">
                                            <a class="post-img" href="<?php echo e('/posts/details/'.$post->post_slug); ?>">
                                                <img src="<?php echo e(asset('public/uploads/'.$post->post_image)); ?>" alt="">
                                            </a>
                                            <div class="post-body">
                                                <div class="post-meta">
                                                    <a class="post-category cat-4" href="javascript:void(0)"><?php echo e(__('Category')); ?></a>
                                                    <span class="post-date"><?php echo e(date('F d, Y', strtotime($post->created_at))); ?></span>
                                                </div>
                                                <h3 class="post-title"><a href="<?php echo e('/posts/details/'.$post->post_slug); ?>"><?php echo e($post->post_title); ?></a></h3>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
                        </div>
                    </div>
                    <div class="col-md-4">

                        <?php if(empty($most_reads)): ?>
                            <div class="aside-widget">
                                <div class="section-title">
                                    <h2>Most Read</h2>
                                </div>
                                <div class="post post-widget">
                                    <a class="post-img" href="blog-post.html">
                                        <img src="img/xwidget-1.jpg.pagespeed.ic.nqEkEDP2_z.jpg" alt="">
                                    </a>
                                    <div class="post-body">
                                        <h3 class="post-title">
                                            <a href="blog-post.html">Title Goes Here</a>
                                        </h3>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="aside-widget">
                            <div class="section-title">
                                <h2>Featured Posts</h2>
                            </div>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!in_array($post->id, $array) && $post->post_section == 'featured' && count($array) <= 16): ?>
                                    <div class="post post-thumb">
                                        <a class="post-img" href="<?php echo e('/posts/details/'.$post->post_slug); ?>">
                                            <img src="<?php echo e(asset('public/uploads/'.$post->post_image)); ?>" alt=""></a>
                                        <div class="post-body">
                                            <div class="post-meta">
                                                <a class="post-category cat-3" href="javascript:void(0)"><?php echo e(__('Category')); ?></a>
                                                <span class="post-date"><?php echo e(date('F d, Y', strtotime($post->created_at))); ?></span>
                                            </div>
                                            <h3 class="post-title"><a href="<?php echo e('/posts/details/'.$post->post_slug); ?>"><?php echo e($post->post_title); ?></a></h3>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
    
                        <div class="aside-widget text-center">
                            <a href="#" style="display: inline-block;margin: auto;">
                                <img class="img-responsive" src="img/xad-1.jpg.pagespeed.ic.C1dNWPxojd.jpg" alt="">
                            </a>
                        </div>
    
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="section section-grey">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="section-title text-center">
						<h2>Featured Posts</h2>
					</div>
				</div>

                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!in_array($post->id, $array) && $post->post_section == 'featured' && count($array) <= 19): ?>
                        <div class="col-md-4">
                            <div class="post">
                                <a class="post-img" href="<?php echo e('/posts/details/'.$post->post_slug); ?>">
                                    <img src="<?php echo e(asset('public/uploads/'.$post->post_image)); ?>" alt="">
                                </a>
                                <div class="post-body">
                                    <div class="post-meta">
                                        <a class="post-category cat-2" href="javascript:void(0)"><?php echo e(__('Category')); ?></a>
                                        <span class="post-date"><?php echo e(date('F d, Y', strtotime($post->created_at))); ?></span>
                                    </div>
                                    <h3 class="post-title"><a href="<?php echo e('/posts/details/'.$post->post_slug); ?>"><?php echo e($post->post_title); ?></a></h3>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</div>
		</div>
	</div>

    <div class="section">
		<div class="container">
			<div class="row">
				<div class="col-md-8">
					<div class="row">
                        <?php if(empty($most_reads)): ?>
                            <div class="col-md-12">
                                <div class="section-title">
                                    <h2>Most Read</h2>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="post post-row">
                                    <a class="post-img" href="blog-post.html"><img
                                            src="img/xpost-4.jpg.pagespeed.ic.acII8ZYTz8.jpg" alt=""></a>
                                    <div class="post-body">
                                        <div class="post-meta">
                                            <a class="post-category cat-2" href="category.html">JavaScript</a>
                                            <span class="post-date">March 27, 2018</span>
                                        </div>
                                        <h3 class="post-title"><a href="blog-post.html">Chrome Extension Protects Against
                                                JavaScript-Based CPU Side-Channel Attacks</a></h3>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                                            incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam...</p>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

						

					</div>
				</div>
				<div class="col-md-4">

					<div class="aside-widget text-center">
						<a href="#" style="display: inline-block;margin: auto;">
							<img class="img-responsive" src="img/xad-1.jpg.pagespeed.ic.C1dNWPxojd.jpg" alt="">
						</a>
					</div>


					<div class="aside-widget">
						<div class="section-title">
							<h2>Catagories</h2>
						</div>
						<div class="category-widget">
							<ul>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="javascript:void(0)" class="cat-1"><?php echo e($category->category_name); ?><span><?php echo e(get_number_of_category_posts($category->id)); ?></span></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
					</div>


					<div class="aside-widget">
						<div class="tags-widget">
							<ul>
								<li><a href="javascript:void(0)">Posts</a></li>
							</ul>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\engrd\OneDrive\Desktop\softdelta\resources\views/welcome.blade.php ENDPATH**/ ?>