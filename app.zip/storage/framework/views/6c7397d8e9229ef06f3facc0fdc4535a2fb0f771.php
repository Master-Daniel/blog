

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layout.guest_navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="single-post spad">
        <div class="single-post__hero set-bg" data-setbg="<?php echo e(url('storage/images/law.jpeg')); ?>"></div>
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-8">
                    <div class="single-post__title">
                        <div class="single-post__title__meta">
                            <h2>10</h2>
                            <span>Sep</span>
                        </div>
                        <div class="single-post__title__text">
                            
                            <h4>David Edevbie Completely Failed To Prove Allegations Of Forgery Against Rt. Hon.  Sheriff Francis Orohwedor Oborevwori</h4>
                            
                        </div>
                    </div>
                    <div class="single-post__social__item">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fa fa-youtube-play"></i></a></li>
                        </ul>
                    </div>
                    <div class="single-post__top__text">
                        <p>Under the Law, forgery cannot be grounded in respect of a document in the absence of its original. In other words, mere presentation of series of documents by a party alleging forgery without pinpointing clearly the original one from the counterfeit cannot establish a case of forgery.</p>
                    </div>
                    <div class="single-post__middle__text">
                        <p>In JOE ODEY AGI VS PDP (2017) & NWLR (Pt. 1595) 386 @ 457 G-F Per OGUNBIYI, JSC has this to say: </p>
                    </div>
                    <div class="single-post__quote">
                        <p>"For forgery or falsification of age to be sustained, the documents purportedly forged must be a false representation of genuine documents. This is because it will be preposterous to allege the forgery of a fake or counterfeit document, as rightly submitted by the senior counsel for the 3rd Respondent. See the cases of ACB Plc. v. Ndoma Egba (2000) 8 NWLR (Pt. 667) 387 at 401, Adelaja v. Alade (1999) 6 NWLR (Pt. 608) 544 at 558, Ikoku v. Oli (1962) 1 SCNLR 307 and Adewale v. Olaifa (2012) 17 NWLR (Pt. 1330) 478. Under the law, forgery cannot be grounded in respect of a document in the absence of its original. In other words, mere presentation of series of documents by a party, alleging forgery, without pinpointing clearly the original one from the counterfeit cannot establish a case of forgery or falsification of age against the 3rd Respondent."</p>
                    </div>
                    <div class="single-post__desc">
                        <p>In CA/ABJ/CV/778/2022 OBOREVWORI SHERIFF FRANCIS OROHWODOR VS DAVID EDEVBIE & 2 ORS delivered on Monday, 29th day of August, 2022 at the Court of Appeal, Abuja Per Ige JCA had this to say at pages 66, 83 and 84 of the Court’s judgment thus: “The 1st Respondent did not call any lucid or credible evidence to support the serious and grave criminal allegations made against the Appellant to justify the invocation of the consequences of Section 29(5) & (6) of the Electoral Act 2022. There was/is no evidence from any of the institutions that issued the said educational certificates and results disclaiming any of the certificates relied upon by the Appellant to seek election to the Office of Governor of Delta State. A situation where the 1st Respondent as Plaintiff did not find it necessary or bothered to inquire from all the institutions and Registry of Courts as to whether or not they issued those certificates or documents and to who were they validly issued, whether to the Appellant or other persons is a complete failure to discharge the onus on the 1st Respondent to prove beyond reasonable doubt the allegations of forgery and faking of documents against the Appellant. The forged documents and their originals must be produced by the 1st Respondent in order to discern which are the originals or authentic certificates and how they were forged. It must be established that the Appellant indeed forged those documents and certificates listed by the 1st Respondent is his Affidavit in Support of the Originating Summons. Failure to call evidence from the institutions that issued the certificates and other impugned documents and the prove of particulars of forgery and fake documents alleged on those certificates and false information allegedly passed to 2nd and 3rd Respondents by the Appellant as contained in the Affidavits of the 1st Respondent knocked the bottom out of the 1st Respondent's case as Plaintiff at the lower Court……”</p>
                    </div>
                    <div class="single-post__more__details">
                        <div class="row">
                            <div class="col-lg-6 col-md-6">
                                <img src="<?php echo e(url('storage/images/img20.jpg')); ?>" alt="">
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <p>“On the variation or what the 1st Respondent referred to as inconsistency in the names of the Appellant, the 1st Respondent made emphatic deposition in his Affidavit that because of those variation or inconsistencies in the name of the Appellant, the Appellant is not the owner of the certificates or documents that he presented to the 2nd and 3rd Respondents. The 1st Respondent failed to prove or establish by the Affidavits evidence before the lower Court the owner of those educational certificates and other documents aside the Appellant who claims the ownership of the documents. The 1st Respondent also failed to proffer any cogent or credible evidence before the lower Court to entitle him to the reliefs sought on the Originating Summons. The heinous allegations of swearing to false Affidavit, forging and faking of educational credentials made by the 1st Respondent against the Appellant cannot be established or proved by mere assertions and comparison carried out by the 1st Respondent in the Supporting Affidavit to his Originating Summons.”</p>
                            </div>
                            <div class="single-post__last__text">
                                <p>The 1st Respondent is under a burden duty to produce the originals of the credentials or certificates claimed by the Appellant as belonging to him and the forged documents and certificates before the lower Court. That is not all he failed to prove that the Appellant actually forged or faked any of the documents or certificates attached to the alleged false Affidavits. Further on the allegations of the 1st Respondent that the Appellant laid claims to various certificates that do not belong to him and contained different and varied names all of which the 1st Defendant now Appellant now fraudulently seeks to ascribe to himself in a chameleonic manner, the 1st Respondent failed to prove any of the allegations that those names do not belong to the Appellant. It is of paramount importance to note that the 1st Respondent sued the Appellant as "OBOREVWORI SHERIFF FRANCIS OROHWEDOR" and by the Supporting Affidavit sworn to by the 1st Respondent, the names of the Appellant are contained in all the documents. The 1st Respondent failed to prove that those names do not belong to the Appellant merely by the arrangement of the names or the person bearing those names apart from the Appellant. The 1st Respondent did not prove or establish to which advantage the names have been used over the 1st Respondent's right to contest and other Aspirants who participated in the PDP's Primaries to elect its candidate for Delta State Governorship Election of 2023 which the Appellant won. The lower Court decision in favour of the 1st Respondent is perverse…… It is therefore my humble submission that the above is the position of the Law on how to prove forgery. Anything short of the above is a mere academic exercise and a journey in futility.
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="single-post__next__previous">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <a href="#" class="single-post__previous">
                                    <h6><span class="arrow_carrot-left"></span> Previous posts</h6>
                                    
                                </a>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <a href="#" class="single-post__next">
                                    <h6>Next posts <span class="arrow_carrot-right"></span> </h6>
                                    
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="single-post__leave__comment">
                        <div class="widget__title">
                            <h4>Leave a comment</h4>
                        </div>
                        <form action="#">
                            <div class="input-list">
                                <input type="text" placeholder="Name">
                                <input type="text" placeholder="Email">
                                <input type="text" placeholder="Website">
                            </div>
                            <textarea placeholder="Message"></textarea>
                            <button type="submit" class="site-btn">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Engr. Daniel Michael\Desktop\softdelta\resources\views/case-forgery.blade.php ENDPATH**/ ?>